﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WhatMoodAreYouIn.Controllers
{
    public class AlternativeController : Controller
    {
        // GET: alt1
        public ActionResult alt1()
        {
            return View();
        }
        public ActionResult alt2()
        {
            return View();
        }
        public ActionResult alt3()
        {
            return View();
        }
        public ActionResult alt4()
        {
            return View();
        }
        public ActionResult alt5()
        {
            return View();
        }
    }
}