﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WhatMoodAreYouIn.Controllers
{
    public class CountryController : Controller
    {
        // GET: Country
        public ActionResult ctry1()
        {
            return View();
        }
        public ActionResult ctry2()
        {
            return View();
        }
        public ActionResult ctry3()
        {
            return View();
        }
        public ActionResult ctry4()
        {
            return View();
        }
        public ActionResult ctry5()
        { 
            return View();
        }
    }
}