﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WhatMoodAreYouIn.Controllers
{
    public class HipHopController : Controller
    {
        // GET: HipHop
        public ActionResult hh1()
        {
            return View();
        }
        public ActionResult hh2()
        {
            return View();
        }
        public ActionResult hh3()
        {
            return View();
        }
        public ActionResult hh4()
        {
            return View();
        }
        public ActionResult hh5()
        {
            return View();
        }
    }
}