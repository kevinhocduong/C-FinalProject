﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WhatMoodAreYouIn.Controllers
{
    public class ChristmasController : Controller
    {
        // GET: Christmas
        public ActionResult chr1()
        {
            return View();
        }
        public ActionResult chr2()
        {
            return View();
        }
        public ActionResult chr3()
        {
            return View();
        }
        public ActionResult chr4()
        {
            return View();
        }
        public ActionResult chr5()
        {
            return View();
        }
    }
}