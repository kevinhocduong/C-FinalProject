﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WhatMoodAreYouIn.Controllers
{
    public class PopController : Controller
    {
        // GET: Pop
        public ActionResult pop1()
        {
            return View();
        }
        public ActionResult pop2()
        {
            return View();
        }
        public ActionResult pop3()
        {
            return View();
        }
        public ActionResult pop4()
        {
            return View();
        }
        public ActionResult pop5()
        {
            return View();
        }
    }
}